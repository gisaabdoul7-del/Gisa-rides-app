# Gisa Rides MVP

Expo/React Native prototype for Android and iOS, focused on Kigali.

## Included
- Rider booking screen and pickup map preview
- Current location permission (when granted)
- Moto/car choice and estimated fare
- Driver-mode demo screen
- Optional Supabase client and initial SQL schema

## Run
1. Install Node.js LTS and compatible Android Studio/Xcode tooling.
2. Copy `.env.example` to `.env` and fill in Supabase URL/key.
3. Run `npm install`, then `npx expo start`.
4. Run `npx expo run:android` for Android; iOS builds require macOS/Xcode or a supported cloud build service.

## Supabase
Run `supabase/schema.sql` in the Supabase SQL editor. Create test auth users and matching profile rows.

## MVP limitations
This is a starter prototype, not a public production service. Without credentials it uses demo mode. Authentication UI, profile creation, driver matching, realtime updates, Google Places/Directions, exact distance calculation, push notifications, payments, driver verification and admin dashboard remain to be built. Even with Supabase configured, those features are not complete.

Current fare default is 500 RWF/km for moto and car. Confirm the car rate before launch. Review RLS/security policies before real users or rider data are involved.
