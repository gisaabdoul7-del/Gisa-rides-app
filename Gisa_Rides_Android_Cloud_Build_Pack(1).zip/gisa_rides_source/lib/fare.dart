import 'dart:math' as math;

/// Initial editable fare rates, based on the examples shared for Gisa Rides.
/// These are estimates because the distance is straight-line GPS distance,
/// not road distance returned by Google Routes API.
const int motoRateFrwPerKm = 500;
const int carRateFrwPerKm = 2500;
const double earthRadiusKm = 6371.0;

int rateForService(String serviceType) =>
    serviceType == 'car' ? carRateFrwPerKm : motoRateFrwPerKm;

double straightLineKm({
  required double startLat,
  required double startLng,
  required double endLat,
  required double endLng,
}) {
  final lat1 = _radians(startLat);
  final lat2 = _radians(endLat);
  final deltaLat = _radians(endLat - startLat);
  final deltaLng = _radians(endLng - startLng);
  final a = math.pow(math.sin(deltaLat / 2), 2) +
      math.cos(lat1) * math.cos(lat2) * math.pow(math.sin(deltaLng / 2), 2);
  final boundedA = a.clamp(0.0, 1.0).toDouble();
  return 2 * earthRadiusKm * math.asin(math.sqrt(boundedA));
}

int estimateFareFrw({required String serviceType, required double distanceKm}) {
  if (!distanceKm.isFinite || distanceKm <= 0) return 0;
  return (distanceKm * rateForService(serviceType)).ceil();
}

double _radians(double degrees) => degrees * math.pi / 180;
