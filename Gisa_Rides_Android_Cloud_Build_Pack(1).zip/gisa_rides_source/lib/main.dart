import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'fare.dart';

const _supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const _supabasePublishableKey = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
const _kigali = LatLng(-1.9441, 30.0619);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final configured = _supabaseUrl.startsWith('https://') &&
      _supabasePublishableKey.isNotEmpty;
  if (configured) {
    await Supabase.initialize(
      url: _supabaseUrl,
      publishableKey: _supabasePublishableKey,
    );
  }
  runApp(GisaRidesApp(configured: configured));
}

SupabaseClient get db => Supabase.instance.client;

class GisaRidesApp extends StatelessWidget {
  const GisaRidesApp({super.key, required this.configured});
  final bool configured;

  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFF087F8C);
    return MaterialApp(
      title: 'Gisa Rides',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: primary),
        scaffoldBackgroundColor: const Color(0xFFF5F8FA),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Color(0xFF102A43),
          elevation: 0,
          centerTitle: false,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: const BorderSide(color: Color(0xFFE4EAF0)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFFF8FAFC),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFDCE4EA)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFDCE4EA)),
          ),
        ),
      ),
      home: configured
          ? const AuthGate()
          : const SetupRequiredScreen(),
    );
  }
}

class SetupRequiredScreen extends StatelessWidget {
  const SetupRequiredScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const _BrandMark(size: 76),
                  const SizedBox(height: 22),
                  Text('Connect Gisa Rides',
                      style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                            fontWeight: FontWeight.w800,
                          )),
                  const SizedBox(height: 12),
                  const Text(
                    'Add your Supabase project URL and publishable key using --dart-define. The setup guide in this project shows the exact commands. No secret service-role key belongs in this mobile app.',
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
        stream: db.auth.onAuthStateChange,
        builder: (context, snapshot) {
          final user = db.auth.currentUser;
          if (user == null) return const AuthPage();
          return RoleGate(key: ValueKey(user.id), userId: user.id);
        },
      );
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _isSignUp = false;
  bool _isDriver = false;
  bool _busy = false;
  bool _hidePassword = true;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      if (_isSignUp) {
        final response = await db.auth.signUp(
          email: _email.text.trim(),
          password: _password.text,
          data: {
            'full_name': _name.text.trim(),
            'account_type': _isDriver ? 'driver' : 'passenger',
          },
        );
        if (!mounted) return;
        final message = response.session == null
            ? 'Account created. Check your email to confirm it, then sign in. Driver accounts need approval before accepting rides.'
            : (_isDriver
                ? 'Account created. Your driver profile is waiting for approval.'
                : 'Welcome to Gisa Rides.');
        _showMessage(context, message);
      } else {
        await db.auth.signInWithPassword(
          email: _email.text.trim(),
          password: _password.text,
        );
      }
    } on AuthException catch (error) {
      if (mounted) _showMessage(context, error.message, isError: true);
    } catch (error) {
      if (mounted) {
        _showMessage(context, 'Could not continue. Check your connection and setup.',
            isError: true);
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 440),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Center(child: _BrandMark(size: 72)),
                    const SizedBox(height: 18),
                    Text('Gisa Rides',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.6,
                            )),
                    const SizedBox(height: 6),
                    const Text('Your journey around Kigali',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Color(0xFF61758A))),
                    const SizedBox(height: 28),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(22),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text(_isSignUp ? 'Create your account' : 'Welcome back',
                                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                        fontWeight: FontWeight.w800,
                                      )),
                              const SizedBox(height: 18),
                              if (_isSignUp) ...[
                                TextFormField(
                                  controller: _name,
                                  textCapitalization: TextCapitalization.words,
                                  decoration: const InputDecoration(
                                    labelText: 'Full name',
                                    prefixIcon: Icon(Icons.person_outline),
                                  ),
                                  validator: (v) => v == null || v.trim().length < 2
                                      ? 'Enter your name'
                                      : null,
                                ),
                                const SizedBox(height: 12),
                              ],
                              TextFormField(
                                controller: _email,
                                keyboardType: TextInputType.emailAddress,
                                autocorrect: false,
                                decoration: const InputDecoration(
                                  labelText: 'Email address',
                                  prefixIcon: Icon(Icons.email_outlined),
                                ),
                                validator: (v) => v == null || !v.contains('@')
                                    ? 'Enter a valid email address'
                                    : null,
                              ),
                              const SizedBox(height: 12),
                              TextFormField(
                                controller: _password,
                                obscureText: _hidePassword,
                                decoration: InputDecoration(
                                  labelText: 'Password (at least 8 characters)',
                                  prefixIcon: const Icon(Icons.lock_outline),
                                  suffixIcon: IconButton(
                                    onPressed: () => setState(() => _hidePassword = !_hidePassword),
                                    icon: Icon(_hidePassword
                                        ? Icons.visibility_outlined
                                        : Icons.visibility_off_outlined),
                                  ),
                                ),
                                validator: (v) => v == null || v.length < 8
                                    ? 'Use at least 8 characters'
                                    : null,
                              ),
                              if (_isSignUp) ...[
                                const SizedBox(height: 16),
                                const Text('I want to use Gisa Rides as'),
                                const SizedBox(height: 8),
                                SegmentedButton<bool>(
                                  segments: const [
                                    ButtonSegment(value: false, label: Text('Passenger'), icon: Icon(Icons.person_pin_circle_outlined)),
                                    ButtonSegment(value: true, label: Text('Driver'), icon: Icon(Icons.two_wheeler)),
                                  ],
                                  selected: {_isDriver},
                                  onSelectionChanged: (value) => setState(() => _isDriver = value.first),
                                ),
                                if (_isDriver)
                                  const Padding(
                                    padding: EdgeInsets.only(top: 8),
                                    child: Text(
                                      'Driver access is pending until Gisa Rides verifies and approves your account.',
                                      style: TextStyle(fontSize: 12, color: Color(0xFF61758A)),
                                    ),
                                  ),
                              ],
                              const SizedBox(height: 20),
                              FilledButton(
                                onPressed: _busy ? null : _submit,
                                style: FilledButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(vertical: 15),
                                ),
                                child: _busy
                                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                                    : Text(_isSignUp ? 'Create account' : 'Sign in'),
                              ),
                              const SizedBox(height: 8),
                              TextButton(
                                onPressed: _busy ? null : () => setState(() => _isSignUp = !_isSignUp),
                                child: Text(_isSignUp
                                    ? 'Already registered? Sign in'
                                    : 'New to Gisa Rides? Create account'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text('Serving Kigali, Rwanda',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Color(0xFF718096), fontSize: 12)),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}

class RoleGate extends StatefulWidget {
  const RoleGate({super.key, required this.userId});
  final String userId;

  @override
  State<RoleGate> createState() => _RoleGateState();
}

class _RoleGateState extends State<RoleGate> {
  late Future<Map<String, dynamic>?> _profileFuture;

  @override
  void initState() {
    super.initState();
    _profileFuture = _getProfile();
  }

  Future<Map<String, dynamic>?> _getProfile() async {
    final result = await db
        .from('profiles')
        .select('id, full_name, role')
        .eq('id', widget.userId)
        .maybeSingle();
    return result;
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>?>(
        future: _profileFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const _LoadingScreen(message: 'Loading your profile…');
          }
          if (snapshot.hasError || snapshot.data == null) {
            return Scaffold(
              appBar: AppBar(title: const Text('Gisa Rides')),
              body: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.sync_problem, size: 44),
                    const SizedBox(height: 12),
                    const Text('Your profile could not be loaded. Confirm that the database SQL setup completed successfully.'),
                    const SizedBox(height: 12),
                    OutlinedButton(onPressed: () => setState(() => _profileFuture = _getProfile()), child: const Text('Retry')),
                    TextButton(onPressed: () => db.auth.signOut(), child: const Text('Sign out')),
                  ]),
                ),
              ),
            );
          }
          final profile = snapshot.data!;
          final role = profile['role'] as String? ?? 'passenger';
          final name = profile['full_name'] as String? ?? 'Gisa Rides user';
          if (role == 'driver_pending') return DriverPendingScreen(name: name);
          if (role == 'driver') return DriverDashboard(userId: widget.userId, name: name);
          return PassengerDashboard(userId: widget.userId, name: name);
        },
      );
}

class PassengerDashboard extends StatefulWidget {
  const PassengerDashboard({super.key, required this.userId, required this.name});
  final String userId;
  final String name;

  @override
  State<PassengerDashboard> createState() => _PassengerDashboardState();
}

class _PassengerDashboardState extends State<PassengerDashboard> {
  GoogleMapController? _mapController;
  LatLng? _pickup;
  LatLng? _destination;
  String _serviceType = 'moto';
  bool _requesting = false;
  String? _message;
  bool _messageError = false;

  double get _distanceKm {
    if (_pickup == null || _destination == null) return 0;
    return straightLineKm(
      startLat: _pickup!.latitude,
      startLng: _pickup!.longitude,
      endLat: _destination!.latitude,
      endLng: _destination!.longitude,
    );
  }

  int get _fare => estimateFareFrw(serviceType: _serviceType, distanceKm: _distanceKm);

  Set<Marker> get _markers => {
        if (_pickup != null)
          Marker(markerId: const MarkerId('pickup'), position: _pickup!, infoWindow: const InfoWindow(title: 'Pickup')),
        if (_destination != null)
          Marker(markerId: const MarkerId('destination'), position: _destination!, infoWindow: const InfoWindow(title: 'Destination')),
      };

  void _mapTapped(LatLng point) {
    setState(() {
      if (_pickup == null) {
        _pickup = point;
      } else if (_destination == null) {
        _destination = point;
      } else {
        _pickup = point;
        _destination = null;
      }
      _message = null;
    });
  }

  Future<void> _setCurrentLocation() async {
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _notice('Turn on your phone location service to use GPS.', error: true);
        return;
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        _notice('Location permission is needed. You can still tap the map to set pickup.', error: true);
        return;
      }
      final position = await Geolocator.getCurrentPosition();
      final point = LatLng(position.latitude, position.longitude);
      setState(() {
        _pickup = point;
        _destination = null;
      });
      await _mapController?.animateCamera(CameraUpdate.newLatLngZoom(point, 15));
    } catch (_) {
      _notice('Could not get your current location. Tap the map to set pickup.', error: true);
    }
  }

  Future<void> _requestRide() async {
    if (_pickup == null || _destination == null) {
      _notice('Set a pickup and destination on the map first.', error: true);
      return;
    }
    if (_distanceKm < 0.05) {
      _notice('Choose a destination a little farther from pickup.', error: true);
      return;
    }
    setState(() => _requesting = true);
    try {
      await db.rpc('request_ride', params: {
        'p_pickup_lat': _pickup!.latitude,
        'p_pickup_lng': _pickup!.longitude,
        'p_destination_lat': _destination!.latitude,
        'p_destination_lng': _destination!.longitude,
        'p_service_type': _serviceType,
      });
      _notice('Ride request sent. A driver can now accept it.');
    } on PostgrestException catch (error) {
      _notice(error.message, error: true);
    } catch (_) {
      _notice('Ride request failed. Confirm your connection and database setup.', error: true);
    } finally {
      if (mounted) setState(() => _requesting = false);
    }
  }

  void _notice(String message, {bool error = false}) {
    if (!mounted) return;
    setState(() {
      _message = message;
      _messageError = error;
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Gisa Rides', style: TextStyle(fontWeight: FontWeight.w800)),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 14),
              child: Center(child: Text('Hi, ${widget.name.split(' ').first}', style: const TextStyle(fontSize: 13))),
            ),
            IconButton(tooltip: 'Sign out', onPressed: () => db.auth.signOut(), icon: const Icon(Icons.logout)),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 6, 16, 10),
                child: Row(
                  children: [
                    const Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Where are you going?', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
                        SizedBox(height: 3),
                        Text('Tap the map for pickup, then destination.', style: TextStyle(color: Color(0xFF627D98), fontSize: 12)),
                      ]),
                    ),
                    IconButton.filledTonal(
                      tooltip: 'Use my current location as pickup',
                      onPressed: _setCurrentLocation,
                      icon: const Icon(Icons.my_location),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: SizedBox(
                    height: 260,
                    child: GoogleMap(
                      initialCameraPosition: const CameraPosition(target: _kigali, zoom: 13),
                      onMapCreated: (controller) => _mapController = controller,
                      onTap: _mapTapped,
                      markers: _markers,
                      myLocationEnabled: false,
                      myLocationButtonEnabled: false,
                      compassEnabled: true,
                      mapToolbarEnabled: false,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(children: [
                  Expanded(child: _LocationSummary(icon: Icons.trip_origin, color: const Color(0xFF16865B), title: 'Pickup', value: _coordinateLabel(_pickup))),
                  const SizedBox(width: 8),
                  Expanded(child: _LocationSummary(icon: Icons.location_on, color: const Color(0xFFCE5252), title: 'Destination', value: _coordinateLabel(_destination))),
                ]),
              ),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(children: [
                  Expanded(child: _ServiceChoice(title: 'Moto', subtitle: '500 FRW/km', icon: Icons.two_wheeler, selected: _serviceType == 'moto', onTap: () => setState(() => _serviceType = 'moto'))),
                  const SizedBox(width: 10),
                  Expanded(child: _ServiceChoice(title: 'Car', subtitle: '2,500 FRW/km', icon: Icons.directions_car_filled_outlined, selected: _serviceType == 'car', onTap: () => setState(() => _serviceType = 'car'))),
                ]),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Row(children: [
                      const Icon(Icons.receipt_long_outlined, color: Color(0xFF087F8C)),
                      const SizedBox(width: 10),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('Estimated fare', style: TextStyle(color: Color(0xFF627D98), fontSize: 12)),
                        Text(_distanceKm > 0 ? '${_distanceKm.toStringAsFixed(2)} km · FRW $_fare' : 'Choose both locations', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                      ])),
                      FilledButton(
                        onPressed: _requesting || _pickup == null || _destination == null ? null : _requestRide,
                        child: _requesting
                            ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Text('Request ride'),
                      ),
                    ]),
                  ),
                ),
              ),
              if (_message != null)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 3),
                  child: Text(_message!, style: TextStyle(fontSize: 12, color: _messageError ? Colors.red.shade700 : const Color(0xFF087F8C))),
                ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 3),
                child: Align(alignment: Alignment.centerLeft, child: Text('Your rides', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800))),
              ),
              Expanded(
                child: StreamBuilder<List<Map<String, dynamic>>>(
                  stream: db.from('rides').stream(primaryKey: ['id']).eq('passenger_id', widget.userId).order('created_at', ascending: false),
                  builder: (context, snapshot) {
                    if (snapshot.hasError) return const Center(child: Text('Could not load rides. Check database permissions.'));
                    if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                    final rides = snapshot.data!.take(4).toList();
                    if (rides.isEmpty) return const Center(child: Text('No rides yet. Your ride requests will appear here.', style: TextStyle(color: Color(0xFF627D98))));
                    return ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 5, 16, 14),
                      itemCount: rides.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (context, index) => _RideHistoryTile(ride: rides[index]),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      );
}

class DriverDashboard extends StatelessWidget {
  const DriverDashboard({super.key, required this.userId, required this.name});
  final String userId;
  final String name;

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: Text('Driver · ${name.split(' ').first}', style: const TextStyle(fontWeight: FontWeight.w800)),
            actions: [IconButton(tooltip: 'Sign out', onPressed: () => db.auth.signOut(), icon: const Icon(Icons.logout))],
            bottom: const TabBar(tabs: [Tab(text: 'Available rides'), Tab(text: 'My trips')]),
          ),
          body: TabBarView(children: [
            _DriverRideList(userId: userId, assigned: false),
            _DriverRideList(userId: userId, assigned: true),
          ]),
        ),
      );
}

class _DriverRideList extends StatelessWidget {
  const _DriverRideList({required this.userId, required this.assigned});
  final String userId;
  final bool assigned;

  Future<void> _accept(BuildContext context, String rideId) async {
    try {
      await db.rpc('accept_ride', params: {'p_ride_id': rideId});
      if (context.mounted) _showMessage(context, 'Ride accepted. Open My trips to update its status.');
    } on PostgrestException catch (error) {
      if (context.mounted) _showMessage(context, error.message, isError: true);
    } catch (_) {
      if (context.mounted) _showMessage(context, 'Could not accept ride. Refresh and try again.', isError: true);
    }
  }

  Future<void> _advance(BuildContext context, Map<String, dynamic> ride) async {
    final String current = ride['status'] as String;
    final String next = switch (current) {
      'accepted' => 'arrived',
      'arrived' => 'in_progress',
      'in_progress' => 'completed',
      _ => current,
    };
    try {
      await db.rpc('update_driver_ride_status', params: {
        'p_ride_id': ride['id'],
        'p_new_status': next,
      });
      if (context.mounted) _showMessage(context, 'Trip status updated to ${_prettyStatus(next)}.');
    } on PostgrestException catch (error) {
      if (context.mounted) _showMessage(context, error.message, isError: true);
    } catch (_) {
      if (context.mounted) _showMessage(context, 'Could not update the trip status.', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final stream = assigned
        ? db.from('rides').stream(primaryKey: ['id']).eq('driver_id', userId).order('created_at', ascending: false)
        : db.from('rides').stream(primaryKey: ['id']).eq('status', 'requested').order('created_at', ascending: false);
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: stream,
      builder: (context, snapshot) {
        if (snapshot.hasError) return const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Could not load rides. Confirm driver approval and database permissions.')));
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        var rides = snapshot.data!;
        if (assigned) {
          rides = rides.where((r) => ['accepted', 'arrived', 'in_progress'].contains(r['status'])).toList();
        }
        if (rides.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(assigned ? Icons.route_outlined : Icons.directions_car_outlined, size: 46, color: const Color(0xFF087F8C)),
                const SizedBox(height: 10),
                Text(assigned ? 'No active trips' : 'No ride requests right now', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
                const SizedBox(height: 5),
                const Text('This list updates when a new request or trip status is received.', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF627D98))),
              ]),
            ),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: rides.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) {
            final ride = rides[index];
            final status = ride['status'] as String;
            final nextLabel = switch (status) {
              'accepted' => 'Mark arrived',
              'arrived' => 'Start trip',
              'in_progress' => 'Complete trip',
              _ => null,
            };
            return _DriverRideCard(
              ride: ride,
              actionLabel: assigned ? nextLabel : 'Accept ride',
              onAction: assigned
                  ? (nextLabel == null ? null : () => _advance(context, ride))
                  : () => _accept(context, ride['id'] as String),
            );
          },
        );
      },
    );
  }
}

class _DriverRideCard extends StatelessWidget {
  const _DriverRideCard({required this.ride, required this.actionLabel, required this.onAction});
  final Map<String, dynamic> ride;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final service = ride['service_type'] == 'car' ? 'Car' : 'Moto';
    final fare = (ride['fare_estimate_frw'] as num?)?.round() ?? 0;
    final distance = (ride['estimated_km'] as num?)?.toDouble() ?? 0;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text('$service request', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
            Text('FRW $fare', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: Color(0xFF087F8C))),
          ]),
          const SizedBox(height: 4),
          Text('${distance.toStringAsFixed(2)} km estimated · ${_prettyStatus(ride['status'] as String)}', style: const TextStyle(color: Color(0xFF627D98), fontSize: 12)),
          const SizedBox(height: 12),
          _CoordinateLine(icon: Icons.trip_origin, label: 'Pickup', lat: ride['pickup_lat'], lng: ride['pickup_lng']),
          const SizedBox(height: 8),
          _CoordinateLine(icon: Icons.location_on, label: 'Destination', lat: ride['destination_lat'], lng: ride['destination_lng']),
          if (actionLabel != null) ...[
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, child: FilledButton(onPressed: onAction, child: Text(actionLabel!))),
          ],
        ]),
      ),
    );
  }
}

class DriverPendingScreen extends StatelessWidget {
  const DriverPendingScreen({super.key, required this.name});
  final String name;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Gisa Rides')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const _BrandMark(size: 68),
              const SizedBox(height: 20),
              Text('Hello, ${name.split(' ').first}', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              const Icon(Icons.verified_user_outlined, size: 42, color: Color(0xFF087F8C)),
              const SizedBox(height: 12),
              const Text('Your driver profile is waiting for approval.', textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
              const SizedBox(height: 8),
              const Text('The Gisa Rides administrator must verify your documents and change your profile role to driver before you can accept rides.', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF627D98))),
              const SizedBox(height: 20),
              OutlinedButton.icon(onPressed: () => db.auth.signOut(), icon: const Icon(Icons.logout), label: const Text('Sign out')),
            ]),
          ),
        ),
      );
}

class _RideHistoryTile extends StatelessWidget {
  const _RideHistoryTile({required this.ride});
  final Map<String, dynamic> ride;

  @override
  Widget build(BuildContext context) {
    final service = ride['service_type'] == 'car' ? 'Car' : 'Moto';
    final status = ride['status'] as String? ?? 'requested';
    final fare = (ride['fare_estimate_frw'] as num?)?.round() ?? 0;
    final distance = (ride['estimated_km'] as num?)?.toDouble() ?? 0;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: const Color(0xFFE5F4F3), borderRadius: BorderRadius.circular(12)), child: Icon(ride['service_type'] == 'car' ? Icons.directions_car : Icons.two_wheeler, color: const Color(0xFF087F8C))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('$service · ${distance.toStringAsFixed(2)} km', style: const TextStyle(fontWeight: FontWeight.w700)),
            Text(_prettyStatus(status), style: const TextStyle(color: Color(0xFF627D98), fontSize: 12)),
          ])),
          Text('FRW $fare', style: const TextStyle(fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }
}

class _ServiceChoice extends StatelessWidget {
  const _ServiceChoice({required this.title, required this.subtitle, required this.icon, required this.selected, required this.onTap});
  final String title;
  final String subtitle;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFFE4F4F3) : Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: selected ? const Color(0xFF087F8C) : const Color(0xFFE1E8ED), width: selected ? 1.5 : 1),
          ),
          child: Row(children: [
            Icon(icon, color: const Color(0xFF087F8C), size: 24),
            const SizedBox(width: 8),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
              Text(subtitle, style: const TextStyle(fontSize: 11, color: Color(0xFF627D98))),
            ])),
            if (selected) const Icon(Icons.check_circle, color: Color(0xFF087F8C), size: 18),
          ]),
        ),
      );
}

class _LocationSummary extends StatelessWidget {
  const _LocationSummary({required this.icon, required this.color, required this.title, required this.value});
  final IconData icon;
  final Color color;
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(13), border: Border.all(color: const Color(0xFFE4EAF0))),
        child: Row(children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 7),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 11, color: Color(0xFF627D98))),
            Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
          ])),
        ]),
      );
}

class _CoordinateLine extends StatelessWidget {
  const _CoordinateLine({required this.icon, required this.label, required this.lat, required this.lng});
  final IconData icon;
  final String label;
  final dynamic lat;
  final dynamic lng;

  @override
  Widget build(BuildContext context) {
    final latitude = (lat as num?)?.toDouble();
    final longitude = (lng as num?)?.toDouble();
    return Row(children: [
      Icon(icon, size: 16, color: const Color(0xFF627D98)),
      const SizedBox(width: 7),
      Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
      Expanded(child: Text(latitude == null || longitude == null ? 'Not set' : '${latitude.toStringAsFixed(5)}, ${longitude.toStringAsFixed(5)}', style: const TextStyle(fontSize: 12, color: Color(0xFF627D98)))),
    ]);
  }
}

class _BrandMark extends StatelessWidget {
  const _BrandMark({required this.size});
  final double size;

  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(color: const Color(0xFF087F8C), borderRadius: BorderRadius.circular(size * .28)),
        child: Icon(Icons.route_rounded, color: Colors.white, size: size * .55),
      );
}

class _LoadingScreen extends StatelessWidget {
  const _LoadingScreen({required this.message});
  final String message;

  @override
  Widget build(BuildContext context) => Scaffold(body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const CircularProgressIndicator(), const SizedBox(height: 14), Text(message)])));
}

String _coordinateLabel(LatLng? point) => point == null ? 'Tap map to set' : '${point.latitude.toStringAsFixed(4)}, ${point.longitude.toStringAsFixed(4)}';

String _prettyStatus(String status) => switch (status) {
      'requested' => 'Finding driver',
      'accepted' => 'Driver accepted',
      'arrived' => 'Driver arrived',
      'in_progress' => 'Trip in progress',
      'completed' => 'Completed',
      'cancelled' => 'Cancelled',
      _ => status,
    };

void _showMessage(BuildContext context, String message, {bool isError = false}) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text(message),
    backgroundColor: isError ? Colors.red.shade700 : const Color(0xFF087F8C),
    behavior: SnackBarBehavior.floating,
  ));
}
